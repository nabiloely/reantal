import axios from 'axios';
import { OdooConfig, Property, Booking, Customer, RevenueData } from '../types';

class OdooService {
  private config: OdooConfig | null = null;

  setConfig(config: OdooConfig) {
    this.config = config;
  }

  private async request<T>(endpoint: string, method: 'GET' | 'POST' = 'GET', data?: any): Promise<T> {
    if (!this.config) {
      throw new Error('Odoo configuration not set');
    }

    const url = `${this.config.url}/api/v1/${endpoint}`;
    
    try {
      const response = await axios({
        method,
        url,
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': this.config.apiKey,
          'X-Database': this.config.database,
          'X-Username': this.config.username,
        },
        data,
      });
      return response.data;
    } catch (error) {
      console.error('Odoo API Error:', error);
      throw error;
    }
  }

  // Property Management
  async getProperties(): Promise<Property[]> {
    return this.request<Property[]>('rental/properties');
  }

  async getProperty(id: string): Promise<Property> {
    return this.request<Property>(`rental/properties/${id}`);
  }

  async createProperty(property: Partial<Property>): Promise<Property> {
    return this.request<Property>('rental/properties', 'POST', property);
  }

  async updateProperty(id: string, property: Partial<Property>): Promise<Property> {
    return this.request<Property>(`rental/properties/${id}`, 'POST', property);
  }

  async deleteProperty(id: string): Promise<void> {
    return this.request<void>(`rental/properties/${id}`, 'POST', { action: 'delete' });
  }

  // Booking Management
  async getBookings(filters?: { status?: string; dateFrom?: string; dateTo?: string }): Promise<Booking[]> {
    const params = new URLSearchParams();
    if (filters?.status) params.append('status', filters.status);
    if (filters?.dateFrom) params.append('date_from', filters.dateFrom);
    if (filters?.dateTo) params.append('date_to', filters.dateTo);
    return this.request<Booking[]>(`rental/bookings?${params.toString()}`);
  }

  async getBooking(id: string): Promise<Booking> {
    return this.request<Booking>(`rental/bookings/${id}`);
  }

  async createBooking(booking: Partial<Booking>): Promise<Booking> {
    return this.request<Booking>('rental/bookings', 'POST', booking);
  }

  async updateBooking(id: string, booking: Partial<Booking>): Promise<Booking> {
    return this.request<Booking>(`rental/bookings/${id}`, 'POST', booking);
  }

  async cancelBooking(id: string): Promise<Booking> {
    return this.request<Booking>(`rental/bookings/${id}/cancel`, 'POST');
  }

  // Customer Management
  async getCustomers(): Promise<Customer[]> {
    return this.request<Customer[]>('rental/customers');
  }

  async getCustomer(id: string): Promise<Customer> {
    return this.request<Customer>(`rental/customers/${id}`);
  }

  async createCustomer(customer: Partial<Customer>): Promise<Customer> {
    return this.request<Customer>('rental/customers', 'POST', customer);
  }

  async updateCustomer(id: string, customer: Partial<Customer>): Promise<Customer> {
    return this.request<Customer>(`rental/customers/${id}`, 'POST', customer);
  }

  // KPI & Analytics
  async getKPIs(dateRange?: string): Promise<any> {
    const params = dateRange ? `?date_range=${dateRange}` : '';
    return this.request<any>(`rental/kpis${params}`);
  }

  async getRevenueData(period?: string): Promise<RevenueData[]> {
    const params = period ? `?period=${period}` : '';
    return this.request<RevenueData[]>(`rental/revenue${params}`);
  }

  async getOccupancyRate(propertyId?: string, dateRange?: string): Promise<number> {
    const params = new URLSearchParams();
    if (propertyId) params.append('property_id', propertyId);
    if (dateRange) params.append('date_range', dateRange);
    return this.request<number>(`rental/occupancy?${params.toString()}`);
  }

  // Reports
  async generateReport(type: string, filters?: any): Promise<Blob> {
    return this.request<Blob>(`rental/reports/${type}`, 'POST', filters);
  }

  // Sync with Odoo
  async syncData(): Promise<{ status: string; message: string }> {
    return this.request<{ status: string; message: string }>('rental/sync', 'POST');
  }

  async getLastSyncTime(): Promise<string> {
    return this.request<string>('rental/sync/last');
  }
}

export const odooService = new OdooService();
export default odooService;
