import React from 'react';
import { KPI } from '../types';
import { 
  DollarSign, 
  Percent, 
  Calendar, 
  Clock, 
  Users, 
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

interface KPICardProps {
  kpi: KPI;
}

const iconMap: Record<string, React.ReactNode> = {
  'dollar-sign': <DollarSign className="w-6 h-6" />,
  'percent': <Percent className="w-6 h-6" />,
  'calendar': <Calendar className="w-6 h-6" />,
  'clock': <Clock className="w-6 h-6" />,
  'users': <Users className="w-6 h-6" />,
  'trending-up': <TrendingUp className="w-6 h-6" />,
};

export const KPICard: React.FC<KPICardProps> = ({ kpi }) => {
  const isPositive = kpi.changeType === 'positive';
  const isNegative = kpi.changeType === 'negative';

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${
          isPositive ? 'bg-emerald-50 text-emerald-600' : 
          isNegative ? 'bg-red-50 text-red-600' : 
          'bg-blue-50 text-blue-600'
        }`}>
          {iconMap[kpi.icon] || <DollarSign className="w-6 h-6" />}
        </div>
        <div className={`flex items-center gap-1 text-sm font-medium ${
          isPositive ? 'text-emerald-600' : 
          isNegative ? 'text-red-600' : 
          'text-gray-500'
        }`}>
          {isPositive && <ArrowUpRight className="w-4 h-4" />}
          {isNegative && <ArrowDownRight className="w-4 h-4" />}
          {Math.abs(kpi.change)}%
        </div>
      </div>
      <div>
        <h3 className="text-gray-500 text-sm font-medium mb-1">{kpi.title}</h3>
        <p className="text-2xl font-bold text-gray-900">{kpi.value}</p>
        <p className="text-gray-400 text-xs mt-2">{kpi.description}</p>
      </div>
    </div>
  );
};

export default KPICard;
