import React from 'react';
import { Customer } from '../types';
import { Mail, Phone, Crown, Award, Medal, Badge } from 'lucide-react';

interface CustomersTableProps {
  customers: Customer[];
  onSelectCustomer?: (customer: Customer) => void;
}

const loyaltyConfig: Record<string, { icon: React.ReactNode; color: string; bg: string; label: string }> = {
  bronze: { 
    icon: <Badge className="w-4 h-4" />, 
    color: 'text-amber-700', 
    bg: 'bg-amber-100',
    label: 'Bronze'
  },
  silver: { 
    icon: <Award className="w-4 h-4" />, 
    color: 'text-gray-700', 
    bg: 'bg-gray-200',
    label: 'Silver'
  },
  gold: { 
    icon: <Medal className="w-4 h-4" />, 
    color: 'text-yellow-700', 
    bg: 'bg-yellow-100',
    label: 'Gold'
  },
  platinum: { 
    icon: <Crown className="w-4 h-4" />, 
    color: 'text-blue-700', 
    bg: 'bg-blue-100',
    label: 'Platinum'
  },
};

export const CustomersTable: React.FC<CustomersTableProps> = ({ customers, onSelectCustomer }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-6 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">Customer Analytics</h3>
        <p className="text-sm text-gray-500">Top customers by loyalty and spending</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Loyalty Tier</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Bookings</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Spent</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Booking</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {customers.map((customer) => (
              <tr 
                key={customer.id} 
                onClick={() => onSelectCustomer?.(customer)}
                className="hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold">
                      {customer.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{customer.name}</p>
                      <p className="text-xs text-gray-500">ID: {customer.id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>{customer.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{customer.phone}</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${loyaltyConfig[customer.loyaltyTier]?.bg} ${loyaltyConfig[customer.loyaltyTier]?.color}`}>
                    {loyaltyConfig[customer.loyaltyTier]?.icon}
                    {loyaltyConfig[customer.loyaltyTier]?.label}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-medium text-gray-900">{customer.totalBookings}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-semibold text-emerald-600">${customer.totalSpent.toLocaleString()}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm text-gray-500">{customer.lastBooking}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CustomersTable;
