import React from 'react';
import { 
  LayoutDashboard, 
  Home, 
  Calendar, 
  Users, 
  DollarSign, 
  Settings,
  Database,
  FileText,
  BarChart3,
  X
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { id: 'properties', label: 'العقارات', icon: Home },
  { id: 'bookings', label: 'الحجوزات', icon: Calendar },
  { id: 'customers', label: 'العملاء', icon: Users },
  { id: 'revenue', label: 'الإيرادات', icon: DollarSign },
  { id: 'analytics', label: 'التحليلات', icon: BarChart3 },
  { id: 'reports', label: 'التقارير', icon: FileText },
  { id: 'odoo-sync', label: 'ربط أودو', icon: Database },
  { id: 'settings', label: 'الإعدادات', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onPageChange, isOpen, onClose }) => {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`
        fixed top-0 left-0 z-50 h-full w-64 bg-gray-900 text-white
        transform transition-transform duration-300 ease-in-out
        lg:translate-x-0 lg:static lg:z-auto
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                  <Home className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-lg font-bold">حجز العقارات</h1>
                  <p className="text-xs text-gray-400">فيلات - شاليهات - أجنحة</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="lg:hidden text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onPageChange(item.id);
                    onClose();
                  }}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium
                    transition-colors duration-200
                    ${isActive 
                      ? 'bg-emerald-600 text-white' 
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                    }
                  `}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
          
          {/* Footer */}
          <div className="p-4 border-t border-gray-800">
            <div className="bg-gray-800 rounded-lg p-4" dir="rtl">
              <div className="flex items-center gap-3 mb-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-medium">متصل بأودو</span>
              </div>
              <p className="text-xs text-gray-400">آخر مزامنة: منذ 5 دقائق</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
