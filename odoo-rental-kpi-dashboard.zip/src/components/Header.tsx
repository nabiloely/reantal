import React from 'react';
import { 
  Menu, 
  Search, 
  Bell, 
  Calendar as CalendarIcon,
  Filter,
  Download
} from 'lucide-react';
import { DashboardFilters } from '../types';

interface HeaderProps {
  onMenuClick: () => void;
  filters: DashboardFilters;
  onFilterChange: (filters: DashboardFilters) => void;
}

const dateRanges = [
  { value: 'today', label: 'اليوم' },
  { value: 'week', label: 'هذا الأسبوع' },
  { value: 'month', label: 'هذا الشهر' },
  { value: 'quarter', label: 'هذا الربع' },
  { value: 'year', label: 'هذا العام' },
  { value: 'custom', label: 'مخصص' },
];

export const Header: React.FC<HeaderProps> = ({ onMenuClick, filters, onFilterChange }) => {
  return (
    <header className="bg-white border-b border-gray-100 px-6 py-4">
      <div className="flex items-center justify-between gap-4">
        {/* Left section */}
        <div className="flex items-center gap-4">
          <button 
            onClick={onMenuClick}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
          >
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
          
          <div className="hidden md:flex items-center gap-2 bg-gray-50 rounded-lg px-4 py-2 w-80" dir="rtl">
            <Search className="w-5 h-5 text-gray-400" />
            <input 
              type="text"
              placeholder="ابحث عن عقارات، حجوزات، عملاء..."
              className="bg-transparent border-none outline-none text-sm w-full text-gray-700 placeholder-gray-400"
            />
          </div>
        </div>
        
        {/* Right section */}
        <div className="flex items-center gap-3">
          {/* Date Range Filter */}
          <div className="hidden sm:flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-gray-500" />
            <select 
              value={filters.dateRange}
              onChange={(e) => onFilterChange({ ...filters, dateRange: e.target.value as any })}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {dateRanges.map((range) => (
                <option key={range.value} value={range.value}>{range.label}</option>
              ))}
            </select>
          </div>
          
          {/* Property Type Filter */}
          <div className="hidden md:flex items-center gap-2" dir="rtl">
            <Filter className="w-4 h-4 text-gray-500" />
            <select 
              value={filters.propertyType}
              onChange={(e) => onFilterChange({ ...filters, propertyType: e.target.value })}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">جميع الأنواع</option>
              <option value="villa">فيلا</option>
              <option value="chalet">شاليه</option>
              <option value="suite">جناح</option>
            </select>
          </div>
          
          {/* Export Button */}
          <button className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors" dir="rtl">
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">تصدير</span>
          </button>
          
          {/* Notifications */}
          <button className="relative p-2 hover:bg-gray-100 rounded-lg">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
          </button>
          
          {/* User Profile */}
          <div className="flex items-center gap-3 pr-3 border-r border-gray-200" dir="rtl">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-semibold text-sm">
              AD
            </div>
            <div className="hidden lg:block">
              <p className="text-sm font-medium text-gray-900">المدير</p>
              <p className="text-xs text-gray-500">مدير النظام</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
