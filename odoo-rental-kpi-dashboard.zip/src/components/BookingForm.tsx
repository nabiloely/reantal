import React, { useState } from 'react';
import { Property } from '../types';
import { X, Calendar, Users, CreditCard, CheckCircle } from 'lucide-react';

interface BookingFormProps {
  property: Property | null;
  onClose: () => void;
  onSubmit: (bookingData: any) => void;
}

export const BookingForm: React.FC<BookingFormProps> = ({ property, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    checkIn: '',
    checkOut: '',
    guests: 1,
    name: '',
    email: '',
    phone: '',
    notes: '',
    paymentMethod: 'credit_card',
  });

  if (!property) return null;

  const calculateNights = () => {
    if (formData.checkIn && formData.checkOut) {
      const start = new Date(formData.checkIn);
      const end = new Date(formData.checkOut);
      const diff = end.getTime() - start.getTime();
      return Math.ceil(diff / (1000 * 60 * 60 * 24));
    }
    return 0;
  };

  const calculateTotal = () => {
    const nights = calculateNights();
    return nights * property.dailyRate;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      propertyId: property.id,
      propertyName: property.name,
      totalAmount: calculateTotal(),
      nights: calculateNights(),
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-100 p-6 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-900">حجز جديد</h2>
            <p className="text-sm text-gray-500">{property.name}</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Property Summary */}
          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-900">{property.name}</p>
                <p className="text-sm text-gray-500">{property.location}</p>
              </div>
              <div className="text-left">
                <p className="text-emerald-600 font-bold">{property.dailyRate.toLocaleString()} ر.س</p>
                <p className="text-xs text-gray-500">في الليلة</p>
              </div>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline ml-1" />
                تاريخ الوصول
              </label>
              <input 
                type="date"
                required
                value={formData.checkIn}
                onChange={(e) => setFormData({ ...formData, checkIn: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline ml-1" />
                تاريخ المغادرة
              </label>
              <input 
                type="date"
                required
                value={formData.checkOut}
                onChange={(e) => setFormData({ ...formData, checkOut: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Guests */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Users className="w-4 h-4 inline ml-1" />
              عدد الضيوف
            </label>
            <select 
              value={formData.guests}
              onChange={(e) => setFormData({ ...formData, guests: parseInt(e.target.value) })}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {Array.from({ length: property.guests || 10 }, (_, i) => i + 1).map(n => (
                <option key={n} value={n}>{n} ضيوف</option>
              ))}
            </select>
          </div>

          {/* Guest Information */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">معلومات الضيف</h3>
            <div>
              <input 
                type="text"
                placeholder="الاسم الكامل"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <input 
                type="email"
                placeholder="البريد الإلكتروني"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <input 
                type="tel"
                placeholder="رقم الجوال"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <textarea 
              placeholder="ملاحظات إضافية (اختياري)"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <CreditCard className="w-4 h-4 inline ml-1" />
              طريقة الدفع
            </label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: 'credit_card', label: 'بطاقة ائتمان' },
                { value: 'bank_transfer', label: 'تحويل بنكي' },
                { value: 'cash', label: 'نقدي' },
              ].map((method) => (
                <button
                  key={method.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, paymentMethod: method.value })}
                  className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                    formData.paymentMethod === method.value
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {method.label}
                </button>
              ))}
            </div>
          </div>

          {/* Total */}
          {calculateNights() > 0 && (
            <div className="bg-gray-50 rounded-xl p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">{calculateNights()} ليالي × {property.dailyRate.toLocaleString()} ر.س</span>
                <span className="text-gray-900">{calculateTotal().toLocaleString()} ر.س</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">رسوم الخدمة (10%)</span>
                <span className="text-gray-900">{(calculateTotal() * 0.1).toLocaleString()} ر.س</span>
              </div>
              <div className="border-t border-gray-200 pt-2 flex justify-between font-bold text-lg">
                <span className="text-gray-900">الإجمالي</span>
                <span className="text-emerald-600">{(calculateTotal() * 1.1).toLocaleString()} ر.س</span>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button 
            type="submit"
            className="w-full py-3 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            تأكيد الحجز
          </button>
        </form>
      </div>
    </div>
  );
};

export default BookingForm;
