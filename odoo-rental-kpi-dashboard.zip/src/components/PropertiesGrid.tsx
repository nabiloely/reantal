import React from 'react';
import { Property } from '../types';
import PropertyCard from './PropertyCard';

interface PropertiesGridProps {
  properties: Property[];
  onSelectProperty?: (property: Property) => void;
}

export const PropertiesGrid: React.FC<PropertiesGridProps> = ({ properties, onSelectProperty }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {properties.map((property) => (
        <PropertyCard 
          key={property.id} 
          property={property} 
          onSelectProperty={onSelectProperty}
        />
      ))}
    </div>
  );
};

export default PropertiesGrid;
