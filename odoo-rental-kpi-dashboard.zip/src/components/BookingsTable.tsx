import React from 'react';
import { Booking } from '../types';
import { 
  CheckCircle, 
  Clock, 
  XCircle, 
  CalendarCheck,
  CreditCard,
  AlertCircle
} from 'lucide-react';

interface BookingsTableProps {
  bookings: Booking[];
  onViewDetails?: (booking: Booking) => void;
}

const statusConfig: Record<string, { icon: React.ReactNode; color: string; bg: string; label: string }> = {
  confirmed: { 
    icon: <CheckCircle className="w-4 h-4" />, 
    color: 'text-emerald-600', 
    bg: 'bg-emerald-50',
    label: 'مؤكد'
  },
  pending: { 
    icon: <Clock className="w-4 h-4" />, 
    color: 'text-amber-600', 
    bg: 'bg-amber-50',
    label: 'قيد الانتظار'
  },
  cancelled: { 
    icon: <XCircle className="w-4 h-4" />, 
    color: 'text-red-600', 
    bg: 'bg-red-50',
    label: 'ملغي'
  },
  completed: { 
    icon: <CalendarCheck className="w-4 h-4" />, 
    color: 'text-blue-600', 
    bg: 'bg-blue-50',
    label: 'مكتمل'
  },
};

const paymentConfig: Record<string, { icon: React.ReactNode; color: string; bg: string; label: string }> = {
  paid: { 
    icon: <CheckCircle className="w-3 h-3" />, 
    color: 'text-emerald-600', 
    bg: 'bg-emerald-50',
    label: 'مدفوع'
  },
  partial: { 
    icon: <AlertCircle className="w-3 h-3" />, 
    color: 'text-amber-600', 
    bg: 'bg-amber-50',
    label: 'جزئي'
  },
  unpaid: { 
    icon: <CreditCard className="w-3 h-3" />, 
    color: 'text-red-600', 
    bg: 'bg-red-50',
    label: 'غير مدفوع'
  },
};

export const BookingsTable: React.FC<BookingsTableProps> = ({ bookings, onViewDetails }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-6 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">الحجوزات الأخيرة</h3>
        <p className="text-sm text-gray-500">آخر أنشطة الحجز</p>
      </div>
      <div className="overflow-x-auto" dir="rtl">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">رقم الحجز</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">العقار</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">العميل</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">التواريخ</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المبلغ</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الحالة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الدفع</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {bookings.map((booking) => (
              <tr key={booking.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-medium text-gray-900">{booking.id}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm text-gray-900">{booking.propertyName}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{booking.customerName}</p>
                    <p className="text-xs text-gray-500">{booking.customerEmail}</p>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    <p>{booking.startDate}</p>
                    <p className="text-xs text-gray-500">إلى {booking.endDate}</p>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-semibold text-gray-900">{booking.totalAmount.toLocaleString()} ر.س</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${statusConfig[booking.status]?.bg} ${statusConfig[booking.status]?.color}`}>
                    {statusConfig[booking.status]?.icon}
                    {statusConfig[booking.status]?.label}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${paymentConfig[booking.paymentStatus]?.bg} ${paymentConfig[booking.paymentStatus]?.color}`}>
                    {paymentConfig[booking.paymentStatus]?.icon}
                    {paymentConfig[booking.paymentStatus]?.label}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button 
                    onClick={() => onViewDetails?.(booking)}
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                  >
                    عرض
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BookingsTable;
