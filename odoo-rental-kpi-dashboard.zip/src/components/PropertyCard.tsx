import React from 'react';
import { Property } from '../types';
import { 
  MapPin,
  Star,
  DollarSign,
  TrendingUp,
  Users,
  Bed,
  Bath,
  Wifi,
  Car,
  Waves,
  Dumbbell
} from 'lucide-react';

interface PropertyCardProps {
  property: Property;
  onSelectProperty?: (property: Property) => void;
}

const typeLabels: Record<string, string> = {
  villa: 'فيلا',
  chalet: 'شاليه',
  suite: 'جناح',
  apartment: 'شقة',
  house: 'منزل',
};

const statusColors: Record<string, string> = {
  available: 'bg-emerald-100 text-emerald-700',
  occupied: 'bg-blue-100 text-blue-700',
  maintenance: 'bg-amber-100 text-amber-700',
  reserved: 'bg-purple-100 text-purple-700',
};

const amenityIcons: Record<string, React.ReactNode> = {
  'مسبح': <Waves className="w-4 h-4" />,
  'واي فاي': <Wifi className="w-4 h-4" />,
  'موقف سيارات': <Car className="w-4 h-4" />,
  'صالة رياضية': <Dumbbell className="w-4 h-4" />,
};

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, onSelectProperty }) => {
  return (
    <div 
      onClick={() => onSelectProperty?.(property)}
      className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-200 cursor-pointer"
    >
      {/* Property Image Placeholder */}
      <div className="h-48 bg-gradient-to-br from-emerald-400 to-teal-500 relative">
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[property.status]}`}>
            {property.status === 'available' ? 'متاح' : 
             property.status === 'occupied' ? 'مشغول' :
             property.status === 'maintenance' ? 'صيانة' : 'محجوز'}
          </span>
        </div>
        <div className="absolute top-3 right-3">
          <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/90 text-gray-700">
            {typeLabels[property.type]}
          </span>
        </div>
        <div className="absolute bottom-3 left-3 right-3">
          <div className="flex items-center gap-1 text-white">
            <Star className="w-4 h-4 fill-white" />
            <span className="font-semibold">{property.rating}</span>
          </div>
        </div>
      </div>
      
      {/* Property Details */}
      <div className="p-4">
        <h4 className="font-bold text-gray-900 mb-2 text-lg">{property.name}</h4>
        
        <div className="flex items-center gap-1 text-gray-500 text-sm mb-3">
          <MapPin className="w-4 h-4" />
          <span>{property.location}</span>
        </div>
        
        {/* Property Features */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Users className="w-4 h-4 text-gray-400" />
            <span>{property.guests} ضيوف</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Bed className="w-4 h-4 text-gray-400" />
            <span>{property.bedrooms} غرف</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Bath className="w-4 h-4 text-gray-400" />
            <span>{property.bathrooms} حمام</span>
          </div>
        </div>
        
        {/* Amenities */}
        {property.amenities && property.amenities.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {property.amenities.slice(0, 3).map((amenity, index) => (
              <span 
                key={index}
                className="inline-flex items-center gap-1 px-2 py-1 bg-gray-50 rounded text-xs text-gray-600"
              >
                {amenityIcons[amenity] || <span className="w-4 h-4" />}
                {amenity}
              </span>
            ))}
            {property.amenities.length > 3 && (
              <span className="px-2 py-1 bg-gray-50 rounded text-xs text-gray-600">
                +{property.amenities.length - 3} المزيد
              </span>
            )}
          </div>
        )}
        
        {/* Pricing */}
        <div className="pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <DollarSign className="w-4 h-4" />
              <span>السعر اليومي</span>
            </div>
            <span className="font-bold text-emerald-600 text-lg">{property.dailyRate.toLocaleString()} ر.س</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 text-gray-500 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>معدل الإشغال</span>
            </div>
            <span className="font-semibold text-gray-900">{property.occupancyRate}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
