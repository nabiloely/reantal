// Types for Rental KPI Dashboard

export interface Property {
  id: string;
  name: string;
  type: 'villa' | 'chalet' | 'suite' | 'apartment' | 'house';
  location: string;
  status: 'available' | 'occupied' | 'maintenance' | 'reserved';
  dailyRate: number;
  monthlyRate: number;
  occupancyRate: number;
  revenue: number;
  bookings: number;
  rating: number;
  guests?: number;
  bedrooms?: number;
  bathrooms?: number;
  amenities?: string[];
  images?: string[];
  description?: string;
}

export interface Booking {
  id: string;
  propertyId: string;
  propertyName: string;
  customerName: string;
  customerEmail: string;
  startDate: string;
  endDate: string;
  totalAmount: number;
  status: 'confirmed' | 'pending' | 'cancelled' | 'completed';
  paymentStatus: 'paid' | 'partial' | 'unpaid';
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalBookings: number;
  totalSpent: number;
  lastBooking: string;
  loyaltyTier: 'bronze' | 'silver' | 'gold' | 'platinum';
}

export interface RevenueData {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
  bookings: number;
}

export interface KPI {
  id: string;
  title: string;
  value: string | number;
  change: number;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: string;
  description: string;
}

export interface OdooConfig {
  url: string;
  database: string;
  username: string;
  apiKey: string;
}

export interface DashboardFilters {
  dateRange: 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom';
  propertyType: string;
  location: string;
  status: string;
}
