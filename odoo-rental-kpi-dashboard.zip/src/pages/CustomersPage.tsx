import React, { useState } from 'react';
import { CustomersTable } from '../components/CustomersTable';
import { mockCustomers } from '../data/mockData';
import { Customer } from '../types';
import { Plus, Search, Filter, Users } from 'lucide-react';

export const CustomersPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTier, setSelectedTier] = useState('all');

  const filteredCustomers = mockCustomers.filter((customer) => {
    const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTier = selectedTier === 'all' || customer.loyaltyTier === selectedTier;
    return matchesSearch && matchesTier;
  });

  const handleCustomerSelect = (customer: Customer) => {
    console.log('Selected customer:', customer);
    // Could open a modal or navigate to customer details
  };

  const stats = {
    total: mockCustomers.length,
    platinum: mockCustomers.filter(c => c.loyaltyTier === 'platinum').length,
    gold: mockCustomers.filter(c => c.loyaltyTier === 'gold').length,
    silver: mockCustomers.filter(c => c.loyaltyTier === 'silver').length,
    bronze: mockCustomers.filter(c => c.loyaltyTier === 'bronze').length,
    totalRevenue: mockCustomers.reduce((acc, c) => acc + c.totalSpent, 0),
    avgBookings: Math.round(mockCustomers.reduce((acc, c) => acc + c.totalBookings, 0) / mockCustomers.length),
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customers</h1>
          <p className="text-gray-500 mt-1">Manage customer relationships and loyalty programs</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors">
          <Plus className="w-4 h-4" />
          Add Customer
        </button>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <div className="flex items-center gap-2 text-gray-500 mb-2">
            <Users className="w-4 h-4" />
            <p className="text-sm">Total</p>
          </div>
          <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-blue-600 mb-2">Platinum</p>
          <p className="text-2xl font-bold text-blue-600">{stats.platinum}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-yellow-600 mb-2">Gold</p>
          <p className="text-2xl font-bold text-yellow-600">{stats.gold}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-600 mb-2">Silver</p>
          <p className="text-2xl font-bold text-gray-600">{stats.silver}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-amber-600 mb-2">Bronze</p>
          <p className="text-2xl font-bold text-amber-600">{stats.bronze}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-500 mb-2">Revenue</p>
          <p className="text-lg font-bold text-gray-900">${(stats.totalRevenue / 1000).toFixed(1)}k</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-500 mb-2">Avg. Bookings</p>
          <p className="text-2xl font-bold text-gray-900">{stats.avgBookings}</p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 flex items-center gap-2 bg-gray-50 rounded-lg px-4 py-2">
            <Search className="w-5 h-5 text-gray-400" />
            <input 
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none outline-none text-sm w-full text-gray-700 placeholder-gray-400"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-500" />
            <select 
              value={selectedTier}
              onChange={(e) => setSelectedTier(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Tiers</option>
              <option value="platinum">Platinum</option>
              <option value="gold">Gold</option>
              <option value="silver">Silver</option>
              <option value="bronze">Bronze</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Customers Table */}
      <CustomersTable customers={filteredCustomers} onSelectCustomer={handleCustomerSelect} />
    </div>
  );
};

export default CustomersPage;
