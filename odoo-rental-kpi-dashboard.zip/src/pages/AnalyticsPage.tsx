import React from 'react';
import { mockRevenueData, mockProperties, mockCustomers } from '../data/mockData';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend
} from 'recharts';
import { TrendingUp, Users, Calendar, DollarSign, Activity, Target } from 'lucide-react';

export const AnalyticsPage: React.FC = () => {
  // Booking trends data
  const bookingTrends = mockRevenueData.map(d => ({
    month: d.month,
    bookings: d.bookings,
    revenue: d.revenue / 1000,
  }));

  // Property performance data
  const propertyPerformance = mockProperties.map(p => ({
    name: p.name.length > 15 ? p.name.substring(0, 15) + '...' : p.name,
    revenue: p.revenue / 1000,
    occupancy: p.occupancyRate,
    bookings: p.bookings,
  }));

  // Customer acquisition data
  const customerData = mockCustomers.map(c => ({
    name: c.name.split(' ')[0],
    bookings: c.totalBookings,
    spent: c.totalSpent / 1000,
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-100">
          <p className="font-semibold text-gray-900 mb-2">{label}</p>
          {payload.map((item: any, index: number) => (
            <div key={index} className="flex items-center gap-2 text-sm" style={{ color: item.color }}>
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
              <span>{item.name}: {item.value}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const kpis = [
    { title: 'Avg. Daily Rate', value: '$185', change: '+8.2%', icon: DollarSign, color: 'emerald' },
    { title: 'Booking Conversion', value: '34%', change: '+5.1%', icon: Target, color: 'blue' },
    { title: 'Customer Lifetime Value', value: '$12,450', change: '+12.3%', icon: Users, color: 'purple' },
    { title: 'Avg. Stay Duration', value: '5.2 days', change: '-2.1%', icon: Calendar, color: 'amber' },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
        <p className="text-gray-500 mt-1">Advanced insights and performance metrics</p>
      </div>
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon;
          const isPositive = kpi.change.startsWith('+');
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-${kpi.color}-50 text-${kpi.color}-600`}>
                  <Icon className="w-6 h-6" />
                </div>
                <span className={`text-sm font-medium ${isPositive ? 'text-emerald-600' : 'text-red-600'}`}>
                  {kpi.change}
                </span>
              </div>
              <h3 className="text-gray-500 text-sm font-medium mb-1">{kpi.title}</h3>
              <p className="text-2xl font-bold text-gray-900">{kpi.value}</p>
            </div>
          );
        })}
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Booking & Revenue Trends */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Booking vs Revenue Trends</h3>
            <p className="text-sm text-gray-500">Correlation between bookings and revenue</p>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={bookingTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="left" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="right" orientation="right" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip content={CustomTooltip} />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="bookings" stroke="#10b981" strokeWidth={2} name="Bookings" />
                <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} name="Revenue ($k)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Property Performance */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Property Performance</h3>
            <p className="text-sm text-gray-500">Revenue and occupancy by property</p>
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={propertyPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" stroke="#9ca3af" fontSize={10} tickLine={false} axisLine={false} angle={-45} textAnchor="end" height={80} />
                <YAxis stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip content={CustomTooltip} />
                <Legend />
                <Bar dataKey="revenue" fill="#10b981" name="Revenue ($k)" />
                <Bar dataKey="occupancy" fill="#3b82f6" name="Occupancy %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* Customer Analytics */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Customer Spending Analysis</h3>
          <p className="text-sm text-gray-500">Top customers by bookings and spending</p>
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={customerData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis type="number" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey="name" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} width={100} />
              <Tooltip content={CustomTooltip} />
              <Legend />
              <Bar dataKey="bookings" fill="#8b5cf6" name="Total Bookings" />
              <Bar dataKey="spent" fill="#f59e0b" name="Spent ($k)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Activity className="w-6 h-6" />
            <h3 className="font-semibold">Occupancy Trend</h3>
          </div>
          <p className="text-3xl font-bold mb-2">76%</p>
          <p className="text-emerald-100 text-sm">+5.2% from last month</p>
        </div>
        
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-6 h-6" />
            <h3 className="font-semibold">Revenue Growth</h3>
          </div>
          <p className="text-3xl font-bold mb-2">12.5%</p>
          <p className="text-blue-100 text-sm">Year over year</p>
        </div>
        
        <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-6 h-6" />
            <h3 className="font-semibold">Customer Retention</h3>
          </div>
          <p className="text-3xl font-bold mb-2">68%</p>
          <p className="text-purple-100 text-sm">Repeat customers</p>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
