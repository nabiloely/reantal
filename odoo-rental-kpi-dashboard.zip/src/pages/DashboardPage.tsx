import React from 'react';
import { KPICard } from '../components/KPICard';
import { RevenueChart } from '../components/RevenueChart';
import { OccupancyChart } from '../components/OccupancyChart';
import { BookingsTable } from '../components/BookingsTable';
import { mockKPIs, mockRevenueData, mockProperties, mockBookings } from '../data/mockData';
import { Booking } from '../types';

interface DashboardPageProps {
  onBookingSelect?: (booking: Booking) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onBookingSelect }) => {
  return (
    <div className="space-y-6" dir="rtl">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">لوحة التحكم</h1>
        <p className="text-gray-500 mt-1">نظرة عامة على مؤشرات الأداء والحجوزات</p>
      </div>
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {mockKPIs.map((kpi) => (
          <KPICard key={kpi.id} kpi={kpi} />
        ))}
      </div>
      
      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RevenueChart data={mockRevenueData} />
        <OccupancyChart properties={mockProperties} />
      </div>
      
      {/* Recent Bookings */}
      <BookingsTable bookings={mockBookings} onViewDetails={onBookingSelect} />
    </div>
  );
};

export default DashboardPage;
