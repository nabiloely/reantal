import React, { useState } from 'react';
import { PropertiesGrid } from '../components/PropertiesGrid';
import { BookingForm } from '../components/BookingForm';
import { mockProperties } from '../data/mockData';
import { Property } from '../types';
import { Search, Filter } from 'lucide-react';

export const PropertiesPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [showBookingForm, setShowBookingForm] = useState(false);

  const filteredProperties = mockProperties.filter((property) => {
    const matchesSearch = property.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         property.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || property.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || property.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handlePropertySelect = (property: Property) => {
    setSelectedProperty(property);
    setShowBookingForm(true);
  };

  const handleBookingSubmit = (bookingData: any) => {
    console.log('New booking:', bookingData);
    setShowBookingForm(false);
    setSelectedProperty(null);
    // Here you would send the booking to Odoo
  };

  return (
    <div className="space-y-6">
      {/* Booking Form Modal */}
      {showBookingForm && selectedProperty && (
        <BookingForm 
          property={selectedProperty}
          onClose={() => {
            setShowBookingForm(false);
            setSelectedProperty(null);
          }}
          onSubmit={handleBookingSubmit}
        />
      )}

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">العقارات المتاحة</h1>
          <p className="text-gray-500 mt-1">احجز الفيلات والشاليهات والأجنحة</p>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 flex items-center gap-2 bg-gray-50 rounded-lg px-4 py-2">
            <Search className="w-5 h-5 text-gray-400" />
            <input 
              type="text"
              placeholder="ابحث عن فيلا، شاليه، جناح..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none outline-none text-sm w-full text-gray-700 placeholder-gray-400"
              dir="rtl"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-500" />
            <select 
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              dir="rtl"
            >
              <option value="all">جميع الأنواع</option>
              <option value="villa">فيلا</option>
              <option value="chalet">شاليه</option>
              <option value="suite">جناح</option>
            </select>
            
            <select 
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              dir="rtl"
            >
              <option value="all">جميع الحالات</option>
              <option value="available">متاح</option>
              <option value="occupied">مشغول</option>
              <option value="maintenance">صيانة</option>
              <option value="reserved">محجوز</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Properties Grid */}
      <PropertiesGrid properties={filteredProperties} onSelectProperty={handlePropertySelect} />
      
      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4" dir="rtl">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-500">إجمالي العقارات</p>
          <p className="text-2xl font-bold text-gray-900">{mockProperties.length}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-500">متاح</p>
          <p className="text-2xl font-bold text-emerald-600">
            {mockProperties.filter(p => p.status === 'available').length}
          </p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-500">مشغول</p>
          <p className="text-2xl font-bold text-blue-600">
            {mockProperties.filter(p => p.status === 'occupied').length}
          </p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <p className="text-sm text-gray-500">متوسط الإشغال</p>
          <p className="text-2xl font-bold text-gray-900">
            {Math.round(mockProperties.reduce((acc, p) => acc + p.occupancyRate, 0) / mockProperties.length)}%
          </p>
        </div>
      </div>
    </div>
  );
};

export default PropertiesPage;
