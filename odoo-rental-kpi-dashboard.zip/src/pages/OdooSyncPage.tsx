import React, { useState } from 'react';
import { Database, RefreshCw, CheckCircle, AlertCircle, Settings } from 'lucide-react';

export const OdooSyncPage: React.FC = () => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSync, setLastSync] = useState('5 minutes ago');
  const [syncStatus, setSyncStatus] = useState<'success' | 'error' | 'idle'>('success');
  const [showConfig, setShowConfig] = useState(false);
  const [config, setConfig] = useState({
    url: 'https://your-odoo-instance.com',
    database: 'rental_db',
    username: 'admin',
    apiKey: '••••••••••••••••',
  });

  const handleSync = async () => {
    setIsSyncing(true);
    setSyncStatus('idle');
    
    // Simulate sync process
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('success');
      setLastSync('Just now');
    }, 2000);
  };

  const syncItems = [
    { name: 'Properties', status: 'synced', count: 8, lastSync: '5 min ago' },
    { name: 'Bookings', status: 'synced', count: 165, lastSync: '5 min ago' },
    { name: 'Customers', status: 'synced', count: 234, lastSync: '5 min ago' },
    { name: 'Invoices', status: 'synced', count: 89, lastSync: '5 min ago' },
    { name: 'Payments', status: 'pending', count: 12, lastSync: 'Pending' },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Odoo Integration</h1>
          <p className="text-gray-500 mt-1">Sync data with your Odoo ERP system</p>
        </div>
        <button 
          onClick={() => setShowConfig(!showConfig)}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
        >
          <Settings className="w-4 h-4" />
          Configuration
        </button>
      </div>
      
      {/* Connection Status */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-lg bg-white/20">
              <Database className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Connected to Odoo</h3>
              <p className="text-emerald-100">Instance: {config.url}</p>
              <p className="text-emerald-100 text-sm">Database: {config.database}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
            <span className="font-medium">Live</span>
          </div>
        </div>
      </div>
      
      {/* Sync Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Data Synchronization</h3>
            <p className="text-sm text-gray-500">Last sync: {lastSync}</p>
          </div>
          <button 
            onClick={handleSync}
            disabled={isSyncing}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-medium transition-colors ${
              isSyncing 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-emerald-600 text-white hover:bg-emerald-700'
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Syncing...' : 'Sync Now'}
          </button>
        </div>
        
        {syncStatus === 'success' && (
          <div className="flex items-center gap-2 p-4 bg-emerald-50 rounded-lg text-emerald-700 mb-6">
            <CheckCircle className="w-5 h-5" />
            <span className="text-sm font-medium">Last sync completed successfully</span>
          </div>
        )}
        
        {/* Sync Items */}
        <div className="space-y-3">
          {syncItems.map((item) => (
            <div 
              key={item.name}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-lg ${
                  item.status === 'synced' 
                    ? 'bg-emerald-100 text-emerald-600' 
                    : 'bg-amber-100 text-amber-600'
                }`}>
                  {item.status === 'synced' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{item.name}</p>
                  <p className="text-sm text-gray-500">{item.count} records</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{item.lastSync}</p>
                <p className={`text-xs ${
                  item.status === 'synced' ? 'text-emerald-600' : 'text-amber-600'
                }`}>
                  {item.status === 'synced' ? 'Up to date' : 'Pending sync'}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Configuration Panel */}
      {showConfig && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Odoo Connection Settings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Odoo URL</label>
              <input 
                type="text"
                value={config.url}
                onChange={(e) => setConfig({ ...config, url: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Database Name</label>
              <input 
                type="text"
                value={config.database}
                onChange={(e) => setConfig({ ...config, database: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
              <input 
                type="text"
                value={config.username}
                onChange={(e) => setConfig({ ...config, username: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">API Key</label>
              <input 
                type="password"
                value={config.apiKey}
                onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <button className="px-6 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors">
              Save Configuration
            </button>
            <button className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
              Test Connection
            </button>
          </div>
        </div>
      )}
      
      {/* API Endpoints Info */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Available API Endpoints</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { method: 'GET', endpoint: '/api/v1/rental/properties', description: 'Get all properties' },
            { method: 'GET', endpoint: '/api/v1/rental/bookings', description: 'Get all bookings' },
            { method: 'POST', endpoint: '/api/v1/rental/bookings', description: 'Create new booking' },
            { method: 'GET', endpoint: '/api/v1/rental/customers', description: 'Get all customers' },
            { method: 'GET', endpoint: '/api/v1/rental/kpis', description: 'Get KPI metrics' },
            { method: 'GET', endpoint: '/api/v1/rental/revenue', description: 'Get revenue data' },
            { method: 'POST', endpoint: '/api/v1/rental/sync', description: 'Trigger data sync' },
            { method: 'GET', endpoint: '/api/v1/rental/reports/{type}', description: 'Generate reports' },
          ].map((api, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  api.method === 'GET' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {api.method}
                </span>
                <code className="text-sm text-gray-700">{api.endpoint}</code>
              </div>
              <p className="text-sm text-gray-500">{api.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OdooSyncPage;
