import React from 'react';
import { FileText, Download, Calendar, BarChart3, PieChart, TrendingUp } from 'lucide-react';

const reports = [
  {
    id: '1',
    title: 'Monthly Revenue Report',
    description: 'Comprehensive revenue analysis by property type and location',
    icon: FileText,
    category: 'Financial',
    format: 'PDF',
    lastGenerated: '2026-01-15',
  },
  {
    id: '2',
    title: 'Occupancy Analysis',
    description: 'Property occupancy rates and trends over time',
    icon: BarChart3,
    category: 'Operations',
    format: 'Excel',
    lastGenerated: '2026-01-14',
  },
  {
    id: '3',
    title: 'Customer Analytics Report',
    description: 'Customer behavior, loyalty tiers, and spending patterns',
    icon: PieChart,
    category: 'Customers',
    format: 'PDF',
    lastGenerated: '2026-01-13',
  },
  {
    id: '4',
    title: 'Booking Performance',
    description: 'Booking trends, conversion rates, and channel analysis',
    icon: TrendingUp,
    category: 'Operations',
    format: 'Excel',
    lastGenerated: '2026-01-12',
  },
  {
    id: '5',
    title: 'Year-End Summary',
    description: 'Annual performance summary with key metrics and insights',
    icon: Calendar,
    category: 'Financial',
    format: 'PDF',
    lastGenerated: '2025-12-31',
  },
  {
    id: '6',
    title: 'Property Comparison',
    description: 'Side-by-side comparison of all property performance metrics',
    icon: BarChart3,
    category: 'Operations',
    format: 'Excel',
    lastGenerated: '2026-01-10',
  },
];

const categories = ['All', 'Financial', 'Operations', 'Customers'];

export const ReportsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = React.useState('All');

  const filteredReports = selectedCategory === 'All' 
    ? reports 
    : reports.filter(r => r.category === selectedCategory);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-500 mt-1">Generate and download analytical reports</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors">
          <FileText className="w-4 h-4" />
          Create Custom Report
        </button>
      </div>
      
      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              selectedCategory === category
                ? 'bg-emerald-600 text-white'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {category}
          </button>
        ))}
      </div>
      
      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredReports.map((report) => {
          const Icon = report.icon;
          return (
            <div 
              key={report.id}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 rounded-lg bg-emerald-50 text-emerald-600">
                  <Icon className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                  {report.format}
                </span>
              </div>
              
              <h3 className="font-semibold text-gray-900 mb-2">{report.title}</h3>
              <p className="text-sm text-gray-500 mb-4">{report.description}</p>
              
              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div>
                  <p className="text-xs text-gray-400">Last generated</p>
                  <p className="text-sm font-medium text-gray-900">{report.lastGenerated}</p>
                </div>
                <button className="flex items-center gap-2 px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition-colors">
                  <Download className="w-4 h-4" />
                  Download
                </button>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Scheduled Reports */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Scheduled Reports</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-4">
              <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Monthly Revenue Summary</p>
                <p className="text-sm text-gray-500">Sent on the 1st of every month</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-emerald-600 font-medium">Active</span>
              <button className="text-gray-400 hover:text-gray-600">
                <FileText className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-4">
              <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Weekly Occupancy Report</p>
                <p className="text-sm text-gray-500">Sent every Monday</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-emerald-600 font-medium">Active</span>
              <button className="text-gray-400 hover:text-gray-600">
                <FileText className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;
